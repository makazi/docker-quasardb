// Starting date
var today = new Date();

// One week earlier
var week = new Date();
week.setTime(week.getTime() - 7*24*60*60*1000);

// One month earlier
var month = new Date();
month.setTime(month.getTime() - 30*24*60*60*1000);

// One year earlier
var year = new Date();
year.setTime(year.getTime() - 365*24*60*60*1000);

// Set up angular modules
angular.module(
	'quasardbGUIApp', [
	'quasardbGUIApp.services',
  	'quasardbGUIApp.controllers',
  	'quasardbGUIApp.directives',
  	'quasardbGUIApp.filters',
  	'ngRoute',
  	'ngAnimate']).

// Set up angular routes
config(['$routeProvider', '$logProvider', function($routeProvider, $logProvider) {
	$routeProvider.
		when("/cluster", {templateUrl: "partials/cluster.html"}).
		when("/cluster/node/:nodeId", {templateUrl: "partials/cluster.html"}).
		otherwise({redirectTo: '/cluster'});
		
	// Set log level
	$logProvider.debugEnabled(false);
}]).

// Set up constants
constant('quasardbSettings', {
    refresh		: 300000,   // Time in milliseconds between GUI refreshing
    max_count	: 100000,   // Default quasardb max entries for one node
    maxPoints	: 300,      // Max drawn points in all graphs
    trigger 	: 95,       // Percentage
    charts		: [
    	{
			'label' 		: 'Aggregated CPU usage',
			'icon' 			: 'b-charts__title-icon b-charts__title-icon_icon_cpu',
			'name'			: ['CPU used'],
			'formatNumber'	: ['CPU'],
			'data'			: ['cpu_average'],
			'max'			: ['100'],
	    	'renderer'		: ['area'],
	    	'width'			: '400',
	    	'height'		: '200',
	    	'stroke'		: 'true',
			'preserve'		: 'true',
			'color'			: ['rgba(110,26,74,0.44)'],
			'refresh'		: 'true',
			'show_limiter'	: 'never'
		},
		{
			'label' 		: 'Aggregated Memory usage',
			'icon' 			: 'b-charts__title-icon b-charts__title-icon_icon_memory',
			'name'			: ['RAM used'],
			'formatNumber'	: ['RAM'],
			'data'			: ['mem'],
	    	'renderer'		: ['area'],
	    	'width'			: '400',
	    	'height'		: '200',
	    	'stroke'		: 'true',
			'preserve'		: 'true',
			'color'			: ['rgba(110,26,74,0.40)'],
			'refresh'		: 'true',
			'show_limiter'	: 'never'
		},
		{
			'label'  			: 'Aggregated persistent size',
			'icon'  			: 'b-charts__title-icon b-charts__title-icon_icon_memory',
			'name'	 		  	: ['Persistent size', 'Persistent count'],
			'formatNumber'  	: ['RAM', 'Objects'],
			'data'  			: ['p_size', 'p_count'],
			'max'				: ['p_max_size', 'p_max_count'],
	    	'renderer'			: ['area', 'dashed_line'],
	    	'dotted'			: '4 5',
	    	'width'				: '400',
	    	'height'			: '200',
	    	'stroke'			: 'true',
			'preserve'			: 'true',
			'color'				: ['rgba(18,119,20,0.42)', 'rgba(149,194,215,0.42)'],
			'refresh'			: 'true',
			'show_limiter'		: 'never'
		},
		{
			'label'  			: 'Aggregated resident size',
			'icon'  			: 'b-charts__title-icon b-charts__title-icon_icon_resident',
			'name'	 		  	: ['Resident size', 'Resident count'],
			'formatNumber'  	: ['RAM', 'Objects'],
			'data'  			: ['r_size', 'r_count'],
			'max'				: ['r_max_size', 'r_max_count'],
	    	'renderer'			: ['area', 'dashed_line'],
	    	'dotted'			: '4 5',
	    	'width'				: '400',
	    	'height'			: '200',
	    	'stroke'			: 'true',
			'preserve'			: 'true',
			'color'				: ['rgba(125,105,11,0.43)', 'rgba(149,194,215,0.42)'],
			'refresh'			: 'true',
			'show_limiter'		: 'never'
		}
	],
	ranges		: [
		{
			'selected' : '',
			'label': '1 h',
			'action': {
				'name': 'setRange',
				'args': ['scope', 'graph','h']
			}
		},
		{
			'selected' : 'selected',
			'label': '1 d',
			'action': {
				'name': 'setRange',
				'args': ['scope', 'graph','d']
			}
		},
		{
			'selected' : '',
			'label': '1 w',
			'action': {
				'name': 'getHistoric',
				'args': ['scope', 'graph', week.format("yyyymmddHHMM"), today.format("yyyymmddHHMM")]
			}
		},
		{
			'selected' : '',
			'label': '1 m',
			'action': {
				'name': 'getHistoric',
				'args': ['scope', 'graph', month.format("yyyymmddHHMM"), today.format("yyyymmddHHMM")]
			}
		},
		{
			'selected' : '',
			'label': '1 y',
			'action': {
				'name': 'getHistoric',
				'args': ['scope', 'graph', year.format("yyyymmddHHMM"), today.format("yyyymmddHHMM")]
			}
		}
	],
	loaderOptions : {
		lines: 13,              // The number of lines to draw
	  	length: 20,             // The length of each line
	  	width: 10,              // The line thickness
	  	radius: 30,             // The radius of the inner circle
	  	corners: 1,             // Corner roundness (0..1)
        rotate: 0,              // The rotation offset
	  	direction: 1,           // 1: clockwise, -1: counterclockwise
		color: '#000',          // #rgb or #rrggbb or array of colors
        speed: 1.1,             // Rounds per second
		trail: 60,              // Afterglow percentage
		shadow: false,          // Whether to render a shadow
		hwaccel: false,         // Whether to use hardware acceleration
		className: 'spinner',   // The CSS class to assign to the spinner
		zIndex: 2e9,            // The z-index (defaults to 2000000000)
		top: '50%',             // Top position relative to parent
		left: '50%'             // Left position relative to parent
	}
});