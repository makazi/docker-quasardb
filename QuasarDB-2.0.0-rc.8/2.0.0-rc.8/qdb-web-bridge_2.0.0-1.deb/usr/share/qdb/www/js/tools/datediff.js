/**
 * @return {string}
 */
Date.DateDiff = function(date_debut, date_fin) {
	var seconds = Math.floor((date_fin - (date_debut))/1000);
    var minutes = Math.floor(seconds/60);
    var hours = Math.floor(minutes/60);
    var days = Math.floor(hours/24);
        
    hours = hours-(days*24);
    minutes = minutes-(days*24*60)-(hours*60);
    // seconds = seconds-(days*24*60*60)-(hours*60*60)-(minutes*60);
    
    return ((days) ? (days + ' d ') : ' ') + pad(hours) + ' h ' + pad(minutes) + ' min';
};

function pad(input) {
    var BASE = "00";
    return input ? BASE .substr(0, 2 - Math.ceil(input / 10)) + input : BASE;
}