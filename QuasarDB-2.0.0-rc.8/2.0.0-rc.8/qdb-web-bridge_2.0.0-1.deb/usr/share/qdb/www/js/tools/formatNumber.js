Rickshaw.namespace('Rickshaw.Fixtures.Number');

Rickshaw.Fixtures.Number.formatRAM = function(y) {
	var abs_y = Math.abs(y);
	if (abs_y >= 1000000000000000)  	{ return y / 1000000000000000 + " P"; }
	else if (abs_y >= 1000000000000)   	{ return y / 1000000000000 + " T"; }
	else if (abs_y >= 1000000000) 		{ return y / 1000000000 + " G"; }
	else if (abs_y >= 1000000)    		{ return y / 1000000 + " M"; }
	else if (abs_y >= 1000)       		{ return y / 1000 + " K"; }
	else if (abs_y < 1 && y > 0)  		{ return y.toFixed(2); }
	else if (abs_y === 0)         		{ return '0'; }
	else                      			{ return y; }
};

Rickshaw.Fixtures.Number.formatCPU = function(y) {
	var abs_y = Math.abs(y);
	return abs_y.toFixed(2) + ' %';
};

Rickshaw.Fixtures.Number.formatObjects = function(y) {
	var abs_y = Math.abs(y);
	if (abs_y >= 1000000000000000)  	{ return y / 1000000000000000 + " P"; }
	else if (abs_y >= 1000000000000)   	{ return y / 1000000000000 + " T"; }
	else if (abs_y >= 1000000000) 		{ return y / 1000000000 + " G"; }
	else if (abs_y >= 1000000)    		{ return y / 1000000 + " m"; }
	else if (abs_y >= 1000)       		{ return y / 1000 + " k"; }
	else if (abs_y < 1 && y > 0)  		{ return y.toFixed(2) + ""; }
	else if (abs_y === 0)         		{ return '0'; }
	else                      			{ return y; }
};

Rickshaw.Fixtures.Number.formatNetworkRate = function (y) {
    var abs_y = Math.abs(y);
    if (abs_y >= 1000000000000000)  	{ return (y / 1000000000000000).toFixed(2) + " Pbps"; }
    else if (abs_y >= 1000000000000)   	{ return (y / 1000000000000).toFixed(2) + " Tbps"; }
    else if (abs_y >= 1000000000) 		{ return (y / 1000000000).toFixed(2) + " Gbps"; }
    else if (abs_y >= 1000000)    		{ return (y / 1000000).toFixed(2) + " Mbps"; }
    else if (abs_y >= 1000)       		{ return (y / 1000).toFixed(2) + " kbps"; }
    else if (abs_y < 1 && y > 0)  		{ return y + " bps"; }
    else if (abs_y === 0)         		{ return '0.00 bps'; }
    else                      			{ return y + " bps"; }
};