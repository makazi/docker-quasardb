angular.module('quasardbGUIApp.filters', []).

filter('bytes', function() {
	return function(bytes, precision) {
		if (bytes==0 || isNaN(parseFloat(bytes)) || !isFinite(bytes)) {
			return '0';
		}

		if (typeof precision === 'undefined') {
			precision = 2;
		}

		var units = ['bytes', 'kB', 'MB', 'GB', 'TB', 'PB'];
		var number = Math.floor(Math.log(bytes) / Math.log(1024));
		if (units[number] === 'bytes') {
			precision = 0;
		}
		return (bytes / Math.pow(1024, Math.floor(number))).toFixed(precision) +  ' ' + units[number];
	};
}).

filter('bignumber', function() {
	return function(value, precision) {
		if (value==0 || isNaN(parseFloat(value)) || !isFinite(value)) {
			return '0';
		}

		if (typeof precision === 'undefined') {
			precision = 2;
		}

		var log1000 = Math.floor(Math.log(value) / Math.log(1000));
		if (log1000 === 0) precision = 0;

		var suffixes = ['', ' k', ' M', ' G', ' T', ' P'];
		return (value / Math.pow(1000, log1000)).toFixed(precision) + suffixes[log1000];
	};
});
